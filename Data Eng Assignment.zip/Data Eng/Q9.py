
for i in range(6):
    for j in range(i+1):
        print("* ", end="")
    print()
print("\n")
for i in range(6):
    for j in range(i, 6):
        print("* ", end="")
    print()