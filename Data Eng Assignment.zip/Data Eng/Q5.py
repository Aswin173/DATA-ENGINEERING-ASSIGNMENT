from re import sub

def camel_case(s):
  mystr = sub(r"(_|-)+", " ", s).title().replace(" ", "")
  return ''.join([s[0].lower(), mystr[1:]])
print(camel_case('Hello world'))