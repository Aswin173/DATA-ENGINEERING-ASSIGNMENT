row_num = int(input("Input the number of rows: "))
col_num = int(input("Input the number of columns: "))
TwoD_list = [[0 for col in range(col_num)] for row in range(row_num)]

for row in range(row_num):
    for col in range(col_num):
        TwoD_list[row][col]= row*col

print(TwoD_list)