n=5
for i in range(0,n):
    print(" "*i,end='')
    for j in range(n,i,-1):
        print(j,end=' ')
    print(" "*(i+i),end='')
    for k in range(i+1,n+1):
        print(k,end=' ')
    print("\n",end='')