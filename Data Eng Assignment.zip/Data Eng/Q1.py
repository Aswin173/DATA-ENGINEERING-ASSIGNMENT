import operator

text = input("Type in: ")

freq = {}

for i in text.split(' '):
    if i.isalpha():
        if i not in freq:
            freq[i] = 1
        elif i in freq:
            freq[i] = freq[i] + 1
    else:
        pass

sorted_freq = sorted(freq.items(), key = operator.itemgetter(0))
print(sorted_freq)

for i in sorted_freq:
    print(i[0], i[1])