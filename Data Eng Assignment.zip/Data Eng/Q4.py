Mystr =  input('Enter the string : ')
k = int(input('Enter k  (value for accepting string) : '))
largerStrings = []

words = Mystr.split(" ")
for word in words:
    if len(word) > k:
        largerStrings.append(word)

print("All the words which are greater than given length ", k, "are ", largerStrings)